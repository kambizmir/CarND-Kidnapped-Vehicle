/*
 * particle_filter.cpp
 *
 *  Created on: Dec 12, 2016
 *      Author: Tiffany Huang
 */

#include <random>
#include <algorithm>
#include <iostream>
#include <numeric>
#include <map>

#include "particle_filter.h"

void ParticleFilter::init(double x, double y, double theta, double std[]) {
	// TODO: Set the number of particles. Initialize all particles to first position (based on estimates of 
	//   x, y, theta and their uncertainties from GPS) and all weights to 1. 
	// Add random Gaussian noise to each particle.
	// NOTE: Consult particle_filter.h for more information about this method (and others in this file).

	num_particles = 50;
	particles = std::vector<Particle> (num_particles);

	std::default_random_engine gen;

	std::normal_distribution<double> dist_x(x, std[0]);
	std::normal_distribution<double> dist_y(y, std[1]);
	std::normal_distribution<double> dist_psi(theta, std[2]);

	for (int i = 0; i < num_particles; i++) {
		Particle pt;

		pt.id= i;
		pt.x = dist_x(gen);
		pt.y = dist_y(gen);
		pt.theta = dist_psi(gen);
		pt.weight = 1;

		particles[i] = pt;
	}

	is_initialized = true;
}

void ParticleFilter::prediction(double delta_t, double std_pos[], double velocity, double yaw_rate) {
	// TODO: Add measurements to each particle and add random Gaussian noise.
	// NOTE: When adding noise you may find std::normal_distribution and std::default_random_engine useful.
	//  http://en.cppreference.com/w/cpp/numeric/random/normal_distribution
	//  http://www.cplusplus.com/reference/random/default_random_engine/

	std::default_random_engine gen;

	double x ;
	double y ;
	double theta ;

	double new_x  ;
	double new_y ;
	double new_theta ;
	
	for(int i=0 ; i<num_particles ; i++){
		
	    x = particles[i].x ;
		y = particles[i].y ;
	    theta = particles[i].theta ;

	    new_x = x + (velocity / yaw_rate) * (sin(theta + yaw_rate * delta_t) - sin(theta)) ;
	    new_y = y + (velocity / yaw_rate) * (cos(theta) - cos(theta + yaw_rate * delta_t)) ;
	    new_theta = theta + yaw_rate * delta_t ;

		std::normal_distribution<double> dist_x(new_x, std_pos[0]);
		std::normal_distribution<double> dist_y(new_y, std_pos[1]);
		std::normal_distribution<double> dist_theta(new_theta, std_pos[2]);

		particles[i].x = dist_x(gen);
		particles[i].y = dist_y(gen);
		particles[i].theta = dist_theta(gen);
	}

}

void ParticleFilter::dataAssociation(std::vector<LandmarkObs> predicted, std::vector<LandmarkObs>& observations) {
	// TODO: Find the predicted measurement that is closest to each observed measurement and assign the 
	//   observed measurement to this particular landmark.
	// NOTE: this method will NOT be called by the grading code. But you will probably find it useful to 
	//   implement this method and use it as a helper during the updateWeights phase.

	double distance = 0;
	double min ;  
	int minIndex= 0;

	std::vector<LandmarkObs> predicted_copy(predicted);
	std::vector<LandmarkObs> observations_copy(observations);

	std::vector<LandmarkObs> result;

	for (int i = 0; i < predicted_copy.size(); i++){

			distance = 0;
			min =1000000000; 
			minIndex = 0;
			for (int j = 0; j < observations_copy.size(); j++){
				distance = sqrt( 
							   ( ( predicted_copy[i].x - observations_copy[j].x ) * ( predicted_copy[i].x - observations_copy[j].x ) ) +
						   	   ( ( predicted_copy[i].y - observations_copy[j].y ) * ( predicted_copy[i].y - observations_copy[j].y ) )
						   	   );
				if (distance < min){
					min = distance;
					minIndex = j;
				}
			}

			observations_copy[minIndex].id = predicted_copy[i].id;
			result.push_back(observations_copy[minIndex]);		
	}

	observations = result;
}

void ParticleFilter::updateWeights(double sensor_range, double std_landmark[], 
		std::vector<LandmarkObs> observations, Map map_landmarks) {
	// TODO: Update the weights of each particle using a mult-variate Gaussian distribution. You can read
	//   more about this distribution here: https://en.wikipedia.org/wiki/Multivariate_normal_distribution
	// NOTE: The observations are given in the VEHICLE'S coordinate system. Your particles are located
	//   according to the MAP'S coordinate system. You will need to transform between the two systems.
	//   Keep in mind that this transformation requires both rotation AND translation (but no scaling).
	//   The following is a good resource for the theory:
	//   https://www.willamette.edu/~gorr/classes/GeneralGraphics/Transforms/transforms2d.htm
	//   and the following is a good resource for the actual equation to implement (look at equation 
	//   3.33. Note that you'll need to switch the minus sign in that equation to a plus to account 
	//   for the fact that the map's y-axis actually points downwards.)
	//   http://planning.cs.uiuc.edu/node99.html


	std::vector<LandmarkObs> all_landmarks_in_range;
	std::vector<LandmarkObs> transformed_observations;

	double sigma_x = std_landmark[0];
	double sigma_y = std_landmark[1];

	for(int i=0 ; i<num_particles ; i++){

		all_landmarks_in_range.clear();
		for (int k = 0; k < map_landmarks.landmark_list.size(); k++){			
			LandmarkObs lm;
			lm.x = map_landmarks.landmark_list[k].x_f;
			lm.y = map_landmarks.landmark_list[k].y_f;
			lm.id = map_landmarks.landmark_list[k].id_i;	

			double distance = sqrt( ( (lm.x-particles[i].x)*(lm.x-particles[i].x) ) + 
									( (lm.y-particles[i].y)*(lm.y-particles[i].y) )
									);

			if(distance <=   sensor_range)
				all_landmarks_in_range.push_back(lm);
		}

		transformed_observations.clear();

		for(int j=0;j<observations.size();j++){

			double alpha = particles[i].theta;
						
			double x_transformed = particles[i].x + observations[j].x * cos(alpha) - observations[j].y * sin(alpha);
			double y_transformed = particles[i].y + observations[j].y * cos(alpha) + observations[j].x * sin(alpha);
					
			LandmarkObs transformed_observation;
			transformed_observation.x = x_transformed;
			transformed_observation.y = y_transformed;
			transformed_observation.id = 0;
			transformed_observations.push_back(transformed_observation);
			
		}

		ParticleFilter::dataAssociation(all_landmarks_in_range ,transformed_observations);

		for (int m = 0; m < transformed_observations.size(); m++){
			double x = transformed_observations[m].x;
			double y = transformed_observations[m].y;

			int id = transformed_observations[m].id;

			int landmark_index = 0;

			for(int a=0; a<all_landmarks_in_range.size() ; a++ ){
				if (all_landmarks_in_range[a].id == id)
				{
					landmark_index = a;
					break;
				}
			}

			double mu_x = all_landmarks_in_range[landmark_index].x;
			double mu_y = all_landmarks_in_range[landmark_index].y;

			double px = 
						 exp ( - (  
									( ( (x-mu_x) * (x-mu_x) ) / ( 2 * sigma_x * sigma_x) ) +  
							  		( ( (y-mu_y) * (y-mu_y) ) / ( 2 * sigma_y * sigma_y) ) 
							  )   ) 
						 /  (2 * 3.14 * sigma_x * sigma_y)  ;			
		
			particles[i].weight *= px;
			
		}		
	}

	double sum =0;
	for (int g = 0; g < particles.size(); ++g){
		sum += particles[g].weight;
	}
	for (int g = 0; g < particles.size(); ++g){	
			particles[g].weight = particles[g].weight/sum;
	}

}

void ParticleFilter::resample() {
	// TODO: Resample particles with replacement with probability proportional to their weight. 
	// NOTE: You may find std::discrete_distribution helpful here.
	//   http://en.cppreference.com/w/cpp/numeric/random/discrete_distribution

	weights.clear();

	for (int i = 0; i < particles.size(); i++){
		weights.push_back ( particles[i].weight ); 
	}

	std::discrete_distribution<int> distribution (weights.begin() , weights.end());

	std::random_device rd;
	std::mt19937 gen(rd()); 

	std::vector<int> randoms; 

    for(int n=0; n<particles.size(); n++) {
        randoms.push_back(distribution(gen));
    }
	
	std::vector<Particle> new_particles;	
	
	for (int i = 0; i < randoms.size(); i++){
		Particle p;
		p.x = particles[randoms[i]] . x;
		p.y = particles[randoms[i]] . y;
		p.theta = particles[randoms[i]] . theta;
		p.id = particles[randoms[i]] . id;
		p.weight  = particles[randoms[i]] .weight ;
		new_particles.push_back(p);
	}

	particles.clear();

	for (int i = 0; i < new_particles.size(); i++){
		particles.push_back(new_particles[i]);
	}

}

void ParticleFilter::write(std::string filename) {
	// You don't need to modify this file.
	std::ofstream dataFile;
	dataFile.open(filename, std::ios::app);
	for (int i = 0; i < num_particles; i++) {
		dataFile << particles[i].x << " " << particles[i].y << " " << particles[i].theta << "\n";
	}
	dataFile.close();
}
